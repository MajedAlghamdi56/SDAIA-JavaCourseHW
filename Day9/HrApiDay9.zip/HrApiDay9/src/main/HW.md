### Tasks:
    - implement the following in the employees project
        - Introduce the ability to get employees by spcifying the hire year
        - Introduce the ability to get employees by spcifying the job ID
        - Use Response Builder in all end points
        - Use Filter to log the request path
        - Use Exception mapper to handle all exceptions and return a json or xml response
        - Apply HATEOAS princible to all returned entities

